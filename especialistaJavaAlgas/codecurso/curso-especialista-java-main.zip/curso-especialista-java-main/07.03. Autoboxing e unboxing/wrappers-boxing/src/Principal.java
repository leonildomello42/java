public class Principal {

    public static void main(String[] args) {
        Integer diasEntrega = 30;
        int diasEntregaInt = diasEntrega;
    }

}
