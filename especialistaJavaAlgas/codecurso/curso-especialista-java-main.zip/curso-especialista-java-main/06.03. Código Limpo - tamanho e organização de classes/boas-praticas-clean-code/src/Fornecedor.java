public class Fornecedor {

    String razaoSocial;

}
