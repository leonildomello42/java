public class CadastroCliente {

    Cliente cadastrar(Cliente cliente) {
        // implementação estaria aqui
        return null;
    }

}
