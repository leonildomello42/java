public class CadastroFornecedor {

    Fornecedor cadastrar(Fornecedor fornecedor) {
        // implementação estaria aqui
        return null;
    }

}
