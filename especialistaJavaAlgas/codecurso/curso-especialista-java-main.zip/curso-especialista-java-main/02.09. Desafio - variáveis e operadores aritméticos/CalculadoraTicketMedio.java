public class CalculadoraTicketMedio {

  public static void main(String[] args) {
    int venda1 = 20;
    int venda2 = 30;
    int venda3 = 100;

    int ticketMedio = (venda1 + venda2 + venda3) / 3;

    System.out.println("Ticket médio: " + ticketMedio);
  }

}
