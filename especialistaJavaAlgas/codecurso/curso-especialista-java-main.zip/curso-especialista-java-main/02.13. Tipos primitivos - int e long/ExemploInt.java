public class ExemploInt {

  public static void main(String[] args) {
    int populacaoUberlandia = 699_097;

    // int populacaoUberlandia2 = 2_147_483_648; // não compila
    int populacaoUberlandia2 = 2_147_483_647;
  }

}