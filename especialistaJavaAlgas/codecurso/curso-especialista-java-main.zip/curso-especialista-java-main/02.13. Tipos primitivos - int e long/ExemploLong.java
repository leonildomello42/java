public class ExemploLong {

  public static void main(String[] args) {
    long populacaoUberlandia = 699_097;

    long populacaoUberlandia2 = 2_147_483_648L;

    // System.out.println(2_147_483_648); // não compila
    System.out.println(2_147_483_648L);
  }

}