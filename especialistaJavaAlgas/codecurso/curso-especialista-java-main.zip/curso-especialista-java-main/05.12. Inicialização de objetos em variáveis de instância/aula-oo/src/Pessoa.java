public class Pessoa {

    String nome = "João";
    String cpf;
    int anoNascimento;

}
