public class Carro {

    String fabricante = "Ford";
    String modelo;
    String cor;
    int anoFabricacao = 2022;
    Pessoa proprietario = new Pessoa();

}
