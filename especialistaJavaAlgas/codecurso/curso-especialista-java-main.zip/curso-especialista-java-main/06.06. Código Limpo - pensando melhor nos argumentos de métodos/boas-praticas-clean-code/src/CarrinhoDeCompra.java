public class CarrinhoDeCompra {

    void adicionarItem(String nomeProduto, double precoUnitario, int quantidade) {
        // TODO implementar
    }

    void adicionarItem(Produto produto, int quantidade) {
        // TODO implementar
    }

}