public class Cliente {

    String nome;
//    byte[] x = new byte[500 * 1024 * 1024];

}
