public class Cliente {

    byte[] x = new byte[100 * 1024 * 1024];

}
