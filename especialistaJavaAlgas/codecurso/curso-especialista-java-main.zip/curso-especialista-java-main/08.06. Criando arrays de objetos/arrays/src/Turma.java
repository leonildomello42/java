public class Turma {

    String identificacao;
    String nomeProfessora;
    Aluno[] alunos;

}
