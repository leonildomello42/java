public class Aluno {

    String nome;
    int idade;

}
