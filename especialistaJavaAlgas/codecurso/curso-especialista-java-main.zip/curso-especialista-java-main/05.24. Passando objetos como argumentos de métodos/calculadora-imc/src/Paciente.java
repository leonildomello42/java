public class Paciente {

    double peso;
    double altura;

}
