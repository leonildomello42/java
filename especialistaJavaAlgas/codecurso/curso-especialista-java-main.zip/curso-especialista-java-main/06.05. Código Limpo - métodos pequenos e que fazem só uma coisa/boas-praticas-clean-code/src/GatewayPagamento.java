public class GatewayPagamento {

    static boolean autorizarPagamento(String numeroCartao, double valor) {
        return true;
    }

}
