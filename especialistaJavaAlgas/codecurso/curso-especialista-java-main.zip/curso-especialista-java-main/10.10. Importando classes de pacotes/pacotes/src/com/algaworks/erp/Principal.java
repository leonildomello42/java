package com.algaworks.erp;

import com.algaworks.erp.comercial.Pedido;
import com.algaworks.erp.estoque.Produto;

public class Principal {

    public static void main(String[] args) {
        Pedido pedido = new Pedido();
        Produto produto = new Produto();

        java.lang.System.out.println("Olá");
        java.lang.String nome = "Thiago";
    }

}
