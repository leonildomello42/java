package com.algaworks.erp.comercial;

import com.algaworks.erp.estoque.Produto;

import java.util.ArrayList;

public class Pedido {

    ArrayList<Produto> produtos;
    Cliente cliente;

}
