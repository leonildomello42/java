package com.algaworks.erp.comercial;

public class Cliente {
}
