package com.algaworks.erp.comercial;

public class Pedido {
}
