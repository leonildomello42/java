public class Pessoa {

    String nome;
    String cpf;
    int anoNascimento;

}
