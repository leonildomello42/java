public class CalculadoraMediaIdade {

  public static void main(String[] args) {
    int minhaIdade = 40;
    int suaIdade = 20;
    int idadeJoao = 50;

    int idadeMedia = (minhaIdade + suaIdade + idadeJoao) / 3;

    System.out.println("Idade média: " + idadeMedia);

  }

}