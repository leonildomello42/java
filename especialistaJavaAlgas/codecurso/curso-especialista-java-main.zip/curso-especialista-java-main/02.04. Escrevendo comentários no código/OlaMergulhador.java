// Você pode comentar uma linha inteira
public class OlaMergulhador { // ou na frente de uma declaração ou instrução

  /*
  public static void main(String[] args) {
    // imprime a mensagem na saída padrão
    System.out.println("Olá, mergulhador!");
  }
  */

}