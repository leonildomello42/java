public class Matematica {

    static double calcularAcrescimo(double valor, double percentual) {
        return valor * ((percentual / 100) + 1);
    }

}
