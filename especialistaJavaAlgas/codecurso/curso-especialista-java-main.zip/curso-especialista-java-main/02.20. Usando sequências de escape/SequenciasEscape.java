public class SequenciasEscape {

  public static void main(String[] args) {
    System.out.println("Oi \"Maria\"");

    System.out.println("Seu nome:\nJoão");

    System.out.println("C:\\Windows");
  }

}