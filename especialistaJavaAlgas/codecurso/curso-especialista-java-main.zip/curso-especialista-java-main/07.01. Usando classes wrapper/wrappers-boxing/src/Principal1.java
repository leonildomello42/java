public class Principal1 {

    public static void main(String[] args) {
        // tipos primitivos
        int diasParaEntrega;
        long codigoEntrega;
        float valorFrete;
        double valorTotal;
        char tipoCliente;
        boolean compraPaga;

        // String é uma classe
        String nomeCliente;
    }

}
