public class Cliente {

    String nome;
    Integer idade;
    Double rendaMensal;

}
