public class Endereco {

    String logradouro;
    String numero;
    String bairro;

}
