package com.algaworks.cartaobeneficio;

public class Estabelecimento {

    public String nome;
    public double saldo;

    public Estabelecimento(String nome) {
        this.nome = nome;
    }

}
