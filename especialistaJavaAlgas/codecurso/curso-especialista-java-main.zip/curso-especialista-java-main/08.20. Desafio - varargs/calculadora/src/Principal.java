public class Principal {

    public static void main(String[] args) {
        double media = Calculadora.calcularMedia(59.2, 89.2,
                10.2, 104.2, 78);
        System.out.printf("Média: %.2f%n", media);
    }

}
