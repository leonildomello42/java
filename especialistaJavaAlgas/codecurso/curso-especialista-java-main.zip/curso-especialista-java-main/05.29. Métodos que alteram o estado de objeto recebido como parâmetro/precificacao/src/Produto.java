public class Produto {

    double precoCusto;
    double precoVenda;

}
