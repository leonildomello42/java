public class Fatura {

    int numero;
    double valorTotal;

}
