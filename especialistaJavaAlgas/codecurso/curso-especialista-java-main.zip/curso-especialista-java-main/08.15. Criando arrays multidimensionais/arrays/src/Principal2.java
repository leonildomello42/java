public class Principal2 {

    public static void main(String[] args) {
        String[][][] cidades = new String[2][2][2];
        cidades[0][0][0] = "Uberlândia";
        cidades[0][0][1] = "Uberaba";
    }

}
