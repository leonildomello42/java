public class Produto {

    int quantidadeEstoque;

    Produto() {
        this.quantidadeEstoque = 10;
        System.out.println("Construindo um produto");
    }

}
