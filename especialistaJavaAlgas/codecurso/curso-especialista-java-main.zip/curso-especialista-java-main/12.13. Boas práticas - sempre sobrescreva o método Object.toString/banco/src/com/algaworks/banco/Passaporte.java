package com.algaworks.banco;

public record Passaporte(String numero, String pais) {
}
