public class Principal {

    public static void main(String[] args) {
//        int[] notas = new int[5];

//        int[] notas;
//        notas = new int[]{8, 5, 4, 9, 10};

//        int[] notas = new int[]{8, 5, 4, 9, 10};

        int[] notas = {8, 5, 4, 9, 10};
    }

}
