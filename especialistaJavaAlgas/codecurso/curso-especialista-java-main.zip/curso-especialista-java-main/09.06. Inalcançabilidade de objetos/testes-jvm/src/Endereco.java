public class Endereco {

    byte[] x = new byte[500 * 1024 * 1024];
    Cliente cliente;

}
