public class Cliente {

    byte[] x = new byte[500 * 1024 * 1024];
    Endereco endereco;

}
