public class IndiceMassaCorporal {

    double resultado;
    double peso;
    double altura;

}
