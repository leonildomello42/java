public class AposentadoriaTempoContribuicao {

    void solicitarAposentadoria(Contribuinte contribuinte) {
        if (contribuinte.estaElegivelParaAposentadoria()) {
            // TODO implementar aqui
        }
    }

}
