public class OlaMergulhador08 {

    public static void main(String args) {
        System.out.println("Olá, mergulhador!");
    }

}