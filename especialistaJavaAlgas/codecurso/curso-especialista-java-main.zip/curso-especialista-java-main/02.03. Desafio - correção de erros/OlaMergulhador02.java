public class OlaMergulhador02 {

    public static void main(string[] args) {
        System.out.println("Olá, mergulhador!");
    }

}