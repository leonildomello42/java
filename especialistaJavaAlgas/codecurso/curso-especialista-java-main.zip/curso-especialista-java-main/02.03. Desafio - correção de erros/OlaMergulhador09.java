public class OlaMergulhador09 {

    public static void Main(String args[]) {
        System.out.println("Olá, mergulhador!");
    }

}