public class Cliente {

    String nome;
    Integer idade;
    Double rendaMensal;
    int pontosProgramaFidelidade;
    boolean ativo;

}
