package com.algaworks.agenda;

public class Principal1 {

    public static void main(String[] args) {
        Integer idade = 30;
        Integer novaIdade = idade + 1;

        Horario horario = new Horario(10, 30);
//        horario.setHora(15);
    }

}
