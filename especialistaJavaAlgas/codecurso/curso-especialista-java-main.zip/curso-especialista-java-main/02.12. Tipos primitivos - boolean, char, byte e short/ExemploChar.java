public class ExemploChar {

  public static void main(String[] args) {
    // char inicialDoNome = "T"; // não compila
    char inicialDoNome = 'T';
    char tipoCliente = '2';
    char simbolo = '@';

    System.out.println(inicialDoNome);
    System.out.println(tipoCliente);
    System.out.println(simbolo);
  }

}