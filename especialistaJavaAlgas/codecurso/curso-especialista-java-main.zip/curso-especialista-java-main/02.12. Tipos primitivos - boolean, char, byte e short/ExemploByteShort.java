public class ExemploByteShort {

  public static void main(String[] args) {
    byte idade = 127; // valor máximo
    // byte idade2 = 128; // não compila

    short quantidadeEstoque = 32767; // valor máximo
    // short quantidadeEstoque2 = 32768; // não compila
  }

}