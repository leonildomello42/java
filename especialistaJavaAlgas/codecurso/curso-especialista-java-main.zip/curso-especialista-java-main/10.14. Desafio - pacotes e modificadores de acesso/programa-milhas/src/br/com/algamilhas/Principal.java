package br.com.algamilhas;

import br.com.algamilhas.pontuacao.Participante;

public class Principal {

    public static void main(String[] args) {
        Participante participante1 = new Participante("João");
    }

}
